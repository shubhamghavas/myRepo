import './Vote.css';
import React, { useState, useEffect } from 'react';
import { useLocation } from "react-router-dom";

import { baseUrl } from '../../Global'

import { Paper, Button} from '@mui/material';
import SendIcon from '@mui/icons-material/Send';

import CandidateButton from './CandidateButton';
import { useNavigate } from "react-router-dom";

import Dialog from "@material-ui/core/Dialog";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";

function Vote() {

    const [candidates, setCandidates] = useState([])
    const [checked, setChecked] = useState(0)
    const location= useLocation(); 
    const navigate = useNavigate();

    useEffect(() => {
        fetch(baseUrl + '/getcandidatelist')
            .then(response => response.json())
            .then(data => {
                console.log(data)
                data.push('None')
                setCandidates(data)
                setChecked(data.length - 1)
            })
    }, []);

    const castVote = () => {
        fetch(baseUrl + '/castvote', {
            method: 'post',
            headers: new Headers({
                "content-type": "application/json"
            }),
            body: JSON.stringify({to: checked,
                                by: location.state.id})
        })
        .then(response => response.json())
        .then(data => {
                console.log(data)
        })
        handleClickToOpen()
    }
    const redirecttosuess = () => {
        navigate('/');
    }

  const [open, setOpen] = React.useState(false);
  
  const handleClickToOpen = () => {
    setOpen(true);
  };
  
  const handleToClose = () => {
    setOpen(false);
  };

    return (
        <div className="container">
            <Paper elevation={6} className="card">
                <h3 className='title'>Candidates</h3>
                {
                    candidates.map((candidate, index) => (
                        <div key={index} className='candidateContainer' onClick={()=> setChecked(index)}>
                                <CandidateButton check={index == checked} name={candidate} />
                        </div>

                    ))
                }
            <br />
            <Button variant='outlined' size='small' fullwidth endIcon={<SendIcon />} onClick={castVote}>Vote to {candidates[checked]}</Button>
            </Paper>
            <Dialog open={open} onClose={handleToClose}>
        <DialogTitle>{"Success"}</DialogTitle>
        <DialogContent>
          <DialogContentText>
            You Have Successfully Casted A Vote!
                     Thank You! 
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={redirecttosuess} 
                  color="primary" autoFocus>
            Close
          </Button>
        </DialogActions>
      </Dialog>
        </div>
    )
}

export default Vote