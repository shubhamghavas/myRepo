// import './VoterLogin.css';
import './UserInput.css';
import React, {useState} from 'react';
import { Paper } from '@mui/material';
import { TextField } from '@mui/material';
import { Button } from '@mui/material';

import { useNavigate } from "react-router-dom";

import Dialog from "@material-ui/core/Dialog";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";

function UserInput() {
    const [username, setusername] = useState("")
    const [password, setpassword] = useState("")
    const [helper, setHelper] = useState("")
    const navigate = useNavigate();
    const [confPassword , setConfPassword] = useState(''); 
    const [error, setError] = useState(false)
   
    

    const redirecttosuess = () => {
        window.location.reload()
    }
    const [open, setOpen] = React.useState(false);
  
    const handleClickToOpen = () => {
      setOpen(true);
    };
    const handleSubmit=(e)=>{
    //   console.log(password);
    //   console.log(confPassword);
        if(password!=confPassword)
      {
          setError(true)
          setHelper("Passwords don't match")
          
      }
      else{
          setError(false)
      }
     
 
    }
    const handleusernamechange=(e)=>{
        setusername(e.target.value);
    }
    const handleConfPasswordChange =(e)=>{
        setConfPassword(e);
        console.log(confPassword);
        handleSubmit();

      }
      const handlepasswordchange = (e)=>{ 
          setpassword(e.target.value);
      }
    
    const handleToClose = () => {
      setOpen(false);
    };

    return (
        <div className="login-container">

            <Paper elevation={6} className="card" >
                <div>

                    <div className="seperate">
                    <TextField
                        fullWidth
                        label="Enter Your Aadhar Number"
                        onChange={(e) => {handleusernamechange(e)}}
                    />
                    </div>
                    <br />
                    <div className="seperate">
                    <TextField

                        fullWidth
                        label="Enter Your Password"
                        type="password"
                        onChange={(e) => {handlepasswordchange(e)}}
                
                    />
                    
                    </div>
                    <div className="seperate">
                    <TextField

                        fullWidth
                        onChange={(e) => {handleConfPasswordChange(e.target.value)}}
                        error={error}
                        id="outlined-error-helper-text"
                        label="Confirm Your Password"
                        type="password"
                        helperText={helper}
                        
                
                    />
                    
                    </div>
                    <div className="button-container">
                        <Button className="left" variant="outlined" >Submit</Button>
                        {/* <Dialog open={open} onClose={handleToClose}>
                     <DialogTitle>{"Wrong Credentials"}</DialogTitle>
                     <DialogContent>
                       <DialogContentText>
                        Username or password is wrong!
                         please try again!
                         </DialogContentText>
                     </DialogContent>
                    <DialogActions>
                        <Button onClick={redirecttosuess} 
                            color="primary" autoFocus>
                            Close
                         </Button>
                    </DialogActions>
                 </Dialog> */}
                    </div>

                </div>
            </Paper>

        </div>
    )
}
    export default UserInput;