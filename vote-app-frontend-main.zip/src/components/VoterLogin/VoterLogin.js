import './VoterLogin.css';
import React, { useState } from 'react';
import { baseUrl } from '../../Global'
import { TextField, Button, Dialog, DialogContent, Grid, Container } from '@mui/material';
import { Link, useNavigate } from "react-router-dom";
import StatusPopup from './StatusPopup';




function VoterLogin() {

  const [helper, setHelper] = useState("")
  const [error, setError] = useState(false)
  const [isSubmitDisabled, setIsSubmitDisabled] = useState(true)
  const [popupStatus, setPopStatus] = useState(false)
  const [popupMessage, setPopupMessage] = useState("")
  const [id, setId] = useState("")
  const navigate = useNavigate()


  const checkIfValid = (value) => {
    setId(value)
    console.log(id)
    if (value == "" || value == null) {
      setError(false)
      setIsSubmitDisabled(true)
      setHelper("")
    }
    else if (!(/^\d+$/.test(value)) || value.length !== 12) {
      setError(true)
      setHelper("Invalid aadhar number")
      setIsSubmitDisabled(true)
    }
    else {
      setError(false)
      setIsSubmitDisabled(false)
      setHelper("")
    }
  }




  const checkStatus = () => {
    fetch(baseUrl + '/status/' + id)
      .then(response => response.json())
      .then(data => {
        if (data.code != 0) {
          setPopupMessage(data.message)
          setPopStatus(true)
        }
        else {

          navigate('/vote', {
            state: {
              id: id,
            }
          });
        }
      });


  }
  const newuser = () => {
    navigate('/UserInput');
  }



  return (
    <div className="login-container" style={{ background: "url(/Images/a1.jpg) center", width: "100%", height: '100vh', display: 'flex', alignItems: "center" }}>

      <Container maxWidth={"md"} fullWidth={true} style={{ border: "1px solid #000000", padding: "5%", background: "rgba(250,250,250,0.8)" }}>


        <TextField
          fullWidth
          error={error}
          id="outlined-error-helper-text"
          label="Enter Your Aadhar Number"
          helperText={helper}
          onChange={(event) => checkIfValid(event.target.value)}
        />
        <br />
        <br />
        <br />

        <Grid container justifyContent="space-between" alignItems="center">
          <Grid item xs={4}>
            <Button className="left" variant="contained" onClick={() => checkStatus()} disabled={isSubmitDisabled}>Submit</Button>
            {<Dialog
              open={popupStatus}
              onClose={() => setPopStatus(false)}
              className="popup"
              PaperProps={{ sx: { height: "15em", width: "20em" } }}
            >
              <DialogContent>
                <StatusPopup message={popupMessage} />
              </DialogContent>
            </Dialog>}
          </Grid>
          <Grid item xs={8}>
            <Button LinkComponent={Link} to="/admin-login" className="right" variant="outlined">Admin Login</Button>
          </Grid>
        </Grid>
      </Container>

    </div>
  );
}


export default VoterLogin;



{/* <Button className="left" variant="contained" onClick={() => newuser()}>NEW USER</Button> */ }
