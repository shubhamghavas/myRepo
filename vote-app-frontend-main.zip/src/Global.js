const baseUrl = "http://3.231.220.99:5000"


export {baseUrl};